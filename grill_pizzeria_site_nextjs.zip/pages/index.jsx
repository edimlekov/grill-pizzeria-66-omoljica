import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone } from "lucide-react";
import Image from "next/image";
import logo from "@/assets/logo66.png"; // logo fajl treba da se nalazi u public/assets kao 'logo66.png'
import bgImage from "@/assets/bg-grill-pizza.jpg"; // pozadinska slika 'bg-grill-pizza.jpg' u public/assets

export default function Home() {
  return (
    <main
      className="min-h-screen text-gray-900"
      style={{
        backgroundImage: `url(${bgImage.src})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <header className="bg-red-600 bg-opacity-90 text-white p-6 shadow-md">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Image src={logo} alt="Logo" width={50} height={50} />
            <h1 className="text-2xl font-bold">Grill & Pizzeria 66 Omoljica</h1>
          </div>
          <div className="flex items-center gap-2">
            <Phone className="w-4 h-4" />
            <span>061 559 0064</span>
          </div>
        </div>
      </header>

      <section className="py-10 bg-white bg-opacity-90 shadow-inner">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-semibold mb-4">Besplatna dostava</h2>
          <p className="text-lg text-gray-700">
            Dostavljamo potpuno besplatno u: Starčevo, Omoljicu, Ivanovo i Banatski Brestovac.
          </p>
        </div>
      </section>

      <section className="py-12 bg-white bg-opacity-90">
        <div className="max-w-5xl mx-auto px-4 grid md:grid-cols-2 gap-8">
          <Card className="shadow-md">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-2">Jela sa roštilja</h3>
              <p className="text-gray-700">Ukusna ponuda sa roštilja, spremljena po domaćoj recepturi.</p>
            </CardContent>
          </Card>
          <Card className="shadow-md">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-2">Preko 17 vrsta pica</h3>
              <p className="text-gray-700">Od klasične Margarita pice do specijaliteta kuće – zadovoljite svaki apetit!</p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="bg-red-100 bg-opacity-90 py-10">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <h2 className="text-2xl font-semibold">Posetite nas</h2>
          <p className="text-lg">Vojvode Živojina Mišića 1, Omoljica</p>
        </div>
      </section>

      <footer className="bg-red-600 bg-opacity-90 text-white text-center py-4">
        <p>&copy; 2025 Grill & Pizzeria 66 Omoljica. Sva prava zadržana.</p>
      </footer>
    </main>
  );
}
